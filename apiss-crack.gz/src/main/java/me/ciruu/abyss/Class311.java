package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
private static class Class311 {
    private final int Field3181;
    private final int Field3182;
    private final int Field3183;
    private final int Field3184;

    Class311(int n, int n2, int n3, int n4) {
        this.Field3181 = n;
        this.Field3182 = n2;
        this.Field3183 = n3;
        this.Field3184 = n4;
    }

    static int Method1132(Class311 class311) {
        return class311.Field3183;
    }

    static int Method1133(Class311 class311) {
        return class311.Field3184;
    }

    static int Method1134(Class311 class311) {
        return class311.Field3181;
    }

    static int Method1135(Class311 class311) {
        return class311.Field3182;
    }
}
