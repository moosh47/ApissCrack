package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public enum Class269 {
    Air,
    Ground,
    Flat,
    Slab,
    Double;

}
