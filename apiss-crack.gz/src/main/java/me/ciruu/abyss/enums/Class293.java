package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public enum Class293 {
    NONE,
    REMOVE,
    STACK,
    MINIMIZE;

}
