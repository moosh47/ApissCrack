package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public enum Class171 {
    N,
    W,
    S,
    E;
}
