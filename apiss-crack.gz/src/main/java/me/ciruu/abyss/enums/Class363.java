package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public enum Class363 {
    PLAIN(0),
    BOLD(1),
    ITALIC(2);

    int Field1206;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private Class363() {
        int var3_1 = 0x0b;
        this.Field1206 = var3_1;
    }

    Class363(int i) {
    }
}
