package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class210
extends MinecraftEvent {
}
