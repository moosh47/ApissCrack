package me.ciruu.abyss;

import java.util.HashMap;
import net.minecraft.util.EnumFacing;

public final class Class276 {
    public static final HashMap Field2217 = new HashMap();

    static {
        Field2217.put(EnumFacing.DOWN, 1);
        Field2217.put(EnumFacing.WEST, 16);
        Field2217.put(EnumFacing.NORTH, 4);
        Field2217.put(EnumFacing.SOUTH, 8);
        Field2217.put(EnumFacing.EAST, 32);
        Field2217.put(EnumFacing.UP, 2);
    }
}
