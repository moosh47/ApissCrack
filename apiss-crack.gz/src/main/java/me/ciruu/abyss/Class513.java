package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class515;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class513 {
    static final int[] Field1936 = new int[Class515.values().length];

    static {
        try {
            Class513.Field1936[Class515.DamageTest.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.Strafe.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.LowHop.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.Boost.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.OnGround.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.Strafe2b.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.GayHop.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.StrafeBoost.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class513.Field1936[Class515.YPort.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
