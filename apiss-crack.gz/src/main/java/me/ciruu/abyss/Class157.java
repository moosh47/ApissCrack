package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class158;
import me.ciruu.abyss.enums.Class159;
import me.ciruu.abyss.enums.Class45;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class157 {
    static final int[] Field350;
    static final int[] Field351;
    static final int[] Field352;

    static {
        Field352 = new int[Class158.values().length];
        try {
            Class157.Field352[Class158.Auto.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field352[Class158.MainHand.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field352[Class158.OffHand.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        Field351 = new int[Class45.values().length];
        try {
            Class157.Field351[Class45.Counter.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field351[Class45.Target.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field351[Class45.Facing.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        Field350 = new int[Class159.values().length];
        try {
            Class157.Field350[Class159.Off.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field350[Class159.Break.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field350[Class159.All.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class157.Field350[Class159.Place.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
