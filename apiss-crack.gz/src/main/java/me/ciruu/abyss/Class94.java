package me.ciruu.abyss;

import me.ciruu.abyss.Class93;
import net.minecraft.network.Packet;

/*
 * Exception performing whole class analysis ignored.
 */
public static class Class94
extends Class93 {
    public Class94(Packet packet) {
        super(packet);
    }
}
