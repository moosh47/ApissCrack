package me.ciruu.abyss;

import me.ciruu.abyss.Class631;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class632 {
    public static void Method3842(Class631 class631) {
    }

    public static void Method3843(Class631 class631, int n, int n2) {
    }

    public static void Method3844(Class631 class631, int n, int n2, int n3) {
    }

    public static void Method3845(Class631 class631, int n, int n2, int n3) {
    }

    public static void Method3846(Class631 class631, int n, int n2, int n3, long l) {
    }

    public static void Method3847(Class631 class631, char c, int n) {
    }

    public static void Method3848(Class631 class631, int n) {
    }

    public static boolean Method3849(Class631 class631, int n, int n2) {
        return (float)n > class631.Method3392() && (float)n < class631.Method3392() + class631.Method3396() && (float)n2 > class631.Method3394() && (float)n2 < class631.Method3394() + class631.Method3397();
    }
}
