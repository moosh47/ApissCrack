package me.ciruu.abyss;

import me.ciruu.abyss.Class101;
import org.jetbrains.annotations.Nullable;

public interface Class631 {
    @Nullable
    public Class101 Method3391();

    public float Method3392();

    public void Method3393(float var1);

    public float Method3394();

    public void Method3395(float var1);

    public float Method3396();

    public float Method3397();

    public boolean Method3398();

    public void Method3399(boolean var1);

    public void Method3400();

    public void Method3401(int var1, int var2);

    public void Method3402(int var1, int var2, int var3);

    public void Method3403(int var1, int var2, int var3);

    public void Method3404(int var1, int var2, int var3, long var4);

    public void Method3405(char var1, int var2);

    public void Method3406(int var1);

    public boolean Method3407(int var1, int var2);
}
