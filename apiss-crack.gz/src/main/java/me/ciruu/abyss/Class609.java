package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class610;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class609 {
    static final int[] Field2575 = new int[Class610.values().length];

    static {
        try {
            Class609.Field2575[Class610.Packet.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class609.Field2575[Class610.Bucket.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class609.Field2575[Class610.AAC.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class609.Field2575[Class610.Anti.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class609.Field2575[Class610.NCP.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
