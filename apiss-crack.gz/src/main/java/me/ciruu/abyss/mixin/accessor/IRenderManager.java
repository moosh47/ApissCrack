package me.ciruu.abyss.mixin.accessor;

public interface IRenderManager {
    public double getRenderPosX();

    public double getRenderPosY();

    public double getRenderPosZ();
}
