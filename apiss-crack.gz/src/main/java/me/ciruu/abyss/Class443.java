package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public static class Class443 {
    private double Field1501;
    private double Field1502;
    private double Field1503;
    private long Field1504;

    public Class443(double d, double d2, double d3, long l) {
        this.Field1501 = d;
        this.Field1502 = d2;
        this.Field1503 = d3;
        this.Field1504 = l;
    }

    public double Method1912() {
        return this.Field1501;
    }

    public double Method1913() {
        return this.Field1502;
    }

    public double Method1914() {
        return this.Field1503;
    }

    public long Method1915() {
        return this.Field1504;
    }

    public void Method1916(double d) {
        this.Field1501 = d;
    }

    public void Method1917(double d) {
        this.Field1502 = d;
    }

    public void Method1918(double d) {
        this.Field1503 = d;
    }

    public void Method1919(long l) {
        this.Field1504 = l;
    }

    static double Method1920(Class443 class443) {
        return class443.Field1501;
    }

    static double Method1921(Class443 class443) {
        return class443.Field1502;
    }

    static double Method1922(Class443 class443) {
        return class443.Field1503;
    }
}
