package me.ciruu.abyss;

import java.awt.Color;
import org.jetbrains.annotations.NotNull;

public final class Class232 {
    @NotNull
    private static final Color Field566;
    @NotNull
    private static final Color Field567;
    @NotNull
    private static final Color Field568;
    @NotNull
    private static final Color Field569;
    public static final Class232 Field570;

    @NotNull
    public final Color Method720() {
        return Field566;
    }

    @NotNull
    public final Color Method721() {
        return Field567;
    }

    @NotNull
    public final Color Method722() {
        return Field568;
    }

    @NotNull
    public final Color Method723() {
        return Field569;
    }

    private Class232() {
    }

    static {
        Class232 class232;
        Field570 = class232 = new Class232();
        Field566 = new Color(235, 166, 1, 255);
        Field567 = new Color(252, 252, 252, 102);
        Field568 = new Color(77, 77, 77, 102);
        Field569 = new Color(202, 202, 202, 255);
    }
}
