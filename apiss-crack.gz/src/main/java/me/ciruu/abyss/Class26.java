package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class26
extends MinecraftEvent {
}
