package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class194;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class193 {
    static final int[] Field457 = new int[Class194.values().length];

    static {
        try {
            Class193.Field457[Class194.Block.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class193.Field457[Class194.Torch.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
