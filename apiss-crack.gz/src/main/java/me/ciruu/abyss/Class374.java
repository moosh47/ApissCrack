package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class76;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class374 {
    static final int[] Field1228 = new int[Class76.values().length];

    static {
        try {
            Class374.Field1228[Class76.AAC.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class374.Field1228[Class76.Pulse.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
