package me.ciruu.abyss;

import me.ciruu.abyss.Class142;

/*
 * Exception performing whole class analysis ignored.
 */
static final class Class213
implements Class142 {
    Class213() {
    }

    @Override
    public Class142 then(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Class142 thenLast(Object object) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean hasNext() {
        return false;
    }

    public Object next() {
        return null;
    }
}
