package me.ciruu.abyss;

import java.util.ArrayList;
import kotlin.jvm.internal.DefaultConstructorMarker;
import me.ciruu.abyss.Class219;
import net.minecraft.client.gui.ScaledResolution;
import org.jetbrains.annotations.NotNull;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class643 {
    @NotNull
    public final ArrayList Method3888() {
        return Class219.Method3624();
    }

    public final void Method3889(@NotNull ArrayList arrayList) {
        Class219.Method3625(arrayList);
    }

    public final int Method3890() {
        return Class219.Method3626();
    }

    public final void Method3891(int n) {
        Class219.Method3627(n);
    }

    @NotNull
    public final ScaledResolution Method3892() {
        return Class219.Method3628();
    }

    public final void Method3893(@NotNull ScaledResolution scaledResolution) {
        Class219.Method3629(scaledResolution);
    }

    @NotNull
    public final Integer[] Method3894() {
        return Class219.Method3630();
    }

    public final void Method3895(@NotNull Integer[] integerArray) {
        Class219.Method3631(integerArray);
    }

    private Class643() {
    }

    public Class643(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }
}
