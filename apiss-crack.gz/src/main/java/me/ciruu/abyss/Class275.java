package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class275 {
    public static final int Field2666 = 1;
    public static final int Field2667 = 2;
    public static final int Field2668 = 4;
    public static final int Field2669 = 8;
    public static final int Field2670 = 16;
    public static final int Field2671 = 32;
    public static final int Field2672 = 63;
}
