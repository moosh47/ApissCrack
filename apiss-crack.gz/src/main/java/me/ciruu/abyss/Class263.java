package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class264;

public final class Class263 {
    public static final int[] Field706 = new int[Class264.values().length];
    public static final int[] Field707;

    static {
        Class263.Field706[Class264.HEX.ordinal()] = 1;
        Class263.Field706[Class264.RGBA.ordinal()] = 2;
        Class263.Field706[Class264.HSL.ordinal()] = 3;
        Field707 = new int[Class264.values().length];
        Class263.Field707[Class264.HEX.ordinal()] = 1;
        Class263.Field707[Class264.RGBA.ordinal()] = 2;
        Class263.Field707[Class264.HSL.ordinal()] = 3;
    }
}
