package me.ciruu.abyss;

import me.ciruu.abyss.Class41;
import net.minecraft.util.math.Vec3d;

public class Class353 {
    private Vec3d Field1527;
    private Class41 Field1528;

    public Class353(Vec3d vec3d, Class41 class41) {
        this.Method1945(vec3d);
        this.Method1946(class41);
    }

    public Vec3d Method1493() {
        return this.Field1527;
    }

    public void Method1945(Vec3d vec3d) {
        this.Field1527 = vec3d;
    }

    public Class41 Method1494() {
        return this.Field1528;
    }

    public void Method1946(Class41 class41) {
        this.Field1528 = class41;
    }
}
