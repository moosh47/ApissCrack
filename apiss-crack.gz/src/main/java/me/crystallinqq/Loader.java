// 
// Decompiled by Procyon v0.6.0
// 

package me.crystallinqq;

import java.io.File;
import java.io.IOException;
import com.sun.jna.Native;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

import me.ciruu.abyss.AbyssMod;

public class Loader implements IFMLLoadingPlugin
{
    public String[] getASMTransformerClass() {
        return new String[0];
    }
    
    public String getModContainerClass() {
        return null;
    }
    
    @Nullable
    public String getSetupClass() {
        return null;
    }
    
    public void injectData(final Map<String, Object> data) {
    }
    
    public String getAccessTransformerClass() {
        return null;
    }
    
    static {
        try {
            final File file = Native.extractFromResourcePath("RocketPwn");
            System.console();
            String sysname = System.getProperty("os.name");
            AbyssMod abyssMod = (AbyssMod)null;
            AbyssMod.log.info(sysname + "(Abyss Loader Crack");
            System.loadLibrary(file.getAbsolutePath());
        }
        catch (final IOException e) {
            e.printStackTrace();
        }
    }
}
